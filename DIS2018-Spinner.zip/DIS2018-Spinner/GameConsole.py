import Tkinter  # For GUI Console
from Tkinter import *


class GameConsole:

    def editButtonEvent(self, event):
        if self.editButton["text"] == "Edit":
            self.editButton["text"] = "Save"
            self.topGiftsLeftEntry["state"] = "normal"
            self.mediumGiftsLeftEntry["state"] = "normal"
            self.lowGiftsLeftEntry["state"] = "normal"
            self.mysteryGiftsLeftEntry["state"] = "normal"

        elif self.editButton["text"] == "Save":
            self.editButton["text"] = "Edit"
            self.topGiftsLeftEntry["state"] = "disabled"
            self.mediumGiftsLeftEntry["state"] = "disabled"
            self.lowGiftsLeftEntry["state"] = "disabled"
            self.mysteryGiftsLeftEntry["state"] = "disabled"

            # TODO: Logic when user is done with editing values, to update DB with new values

    def checkButtonEvent(self, event):
        print "============="
        print "Top: " + self.topGiftsLeftEntry.get()
        print "Medium: " + self.mediumGiftsLeftEntry.get()
        print "Low: " + self.lowGiftsLeftEntry.get()
        print "Mystery: " + self.mysteryGiftsLeftEntry.get()

    def decrementTopButtonEvent(self, event):
        self.topGiftsLeftValue.set(int(self.topGiftsLeftEntry.get()) - 1)

    def decrementMediumButtonEvent(self, event):
        self.mediumGiftsLeftValue.set(int(self.mediumGiftsLeftEntry.get()) - 1)

    def decrementLowButtonEvent(self, event):
        self.lowGiftsLeftValue.set(int(self.lowGiftsLeftEntry.get()) - 1)

    def decrementMysteryButtonEvent(self, event):
        self.mysteryGiftsLeftValue.set(int(self.mysteryGiftsLeftEntry.get()) - 1)

    def __init__(self, master):

        self.topGiftsLeftValue = IntVar()
        self.mediumGiftsLeftValue = IntVar()
        self.lowGiftsLeftValue = IntVar()
        self.mysteryGiftsLeftValue = IntVar()

        # Initialise values to be displayed initially
        # TODO: Retreive values from DB to be populate fields
        self.topGiftsLeftValue.set(40)
        self.mediumGiftsLeftValue.set(100)
        self.lowGiftsLeftValue.set(750)
        self.mysteryGiftsLeftValue.set(15)

        # Initialise the Frame
        self.fm1 = Tkinter.Frame(master)

        self.topGiftsLeftLabel = Tkinter.Label(self.fm1, text="Top Gifts Left: ")
        self.topGiftsLeftLabel.pack(side=LEFT)
        self.topGiftsLeftEntry = Tkinter.Entry(self.fm1, state="disabled", text=self.topGiftsLeftValue)
        self.topGiftsLeftEntry.pack(side=LEFT)

        self.mediumGiftsLeftLabel = Tkinter.Label(self.fm1, text="Medium Gifts Left: ")
        self.mediumGiftsLeftLabel.pack(side=LEFT, anchor=W, fill=X, expand=YES)
        self.mediumGiftsLeftEntry = Tkinter.Entry(self.fm1, state="disabled", text=self.mediumGiftsLeftValue)
        self.mediumGiftsLeftEntry.pack(side=LEFT)

        self.lowGiftsLeftLabel = Tkinter.Label(self.fm1, text="Low Gifts Left: ")
        self.lowGiftsLeftLabel.pack(side=LEFT, anchor=W, fill=X, expand=YES)
        self.lowGiftsLeftEntry = Tkinter.Entry(self.fm1, state="disabled", text=self.lowGiftsLeftValue)
        self.lowGiftsLeftEntry.pack(side=LEFT)

        self.mysterGiftsLeftLabel = Tkinter.Label(self.fm1, text="Mystery Gifts Left: ")
        self.mysterGiftsLeftLabel.pack(side=LEFT, anchor=W, fill=X, expand=YES)
        self.mysteryGiftsLeftEntry = Tkinter.Entry(self.fm1, state="disabled", text=self.mysteryGiftsLeftValue)
        self.mysteryGiftsLeftEntry.pack(side=LEFT)

        self.editButton = Tkinter.Button(self.fm1, text="Edit")
        self.editButton.pack(side=LEFT)
        self.editButton.bind('<Button-1>', self.editButtonEvent)

        self.checkButton = Tkinter.Button(self.fm1, text="Check")
        self.checkButton.pack(side=LEFT)
        self.checkButton.bind('<Button-1>', self.checkButtonEvent)

        self.fm1.pack(fill=BOTH, expand=YES)

        self.fm2 = Tkinter.Frame(master)
        # TODO: QR Code Image here
        self.fm2.pack(fill=BOTH, expand=YES)

        self.fm1.pack(fill=BOTH, expand=YES)

        # Default placeholder texts
        self.qrCodePlaceholder = StringVar()
        self.qrCodePlaceholder.set("<awaiting QR Code to be Scanned>")
        self.truePlaceholder = StringVar()
        self.truePlaceholder.set("T")
        self.falsePlaceholder = StringVar()
        self.falsePlaceholder.set("F")

        self.fm3 = Tkinter.Frame(master)

        self.nameLabel = Tkinter.Label(self.fm3, text="Name: ")
        self.nameLabel.pack(side=LEFT)
        self.nameEntry = Tkinter.Entry(self.fm3, state="disabled", text=self.qrCodePlaceholder, width=50)
        self.nameEntry.pack(side=LEFT)

        self.emailLabel = Tkinter.Label(self.fm3, text="Email: ")
        self.emailLabel.pack(side=LEFT, anchor=W, fill=X, expand=YES)
        self.emailEntry = Tkinter.Entry(self.fm3, state="disabled", text=self.qrCodePlaceholder, width=50)
        self.emailEntry.pack(side=LEFT)

        self.isFirstTryLabel = Tkinter.Label(self.fm3, text="isFirstTry: ")
        self.isFirstTryLabel.pack(side=LEFT, anchor=W, fill=X, expand=YES)
        self.isFirstTryEntry = Tkinter.Entry(self.fm3, state="disabled", text=self.truePlaceholder, width=5)
        self.isFirstTryEntry.pack(side=LEFT)

        self.isTopTierForFirstTryLabel = Tkinter.Label(self.fm3, text="isTopTierForFirstTry: ")
        self.isTopTierForFirstTryLabel.pack(side=LEFT, anchor=W, fill=X, expand=YES)
        self.isTopTierForFirstTryEntry = Tkinter.Entry(self.fm3, state="disabled", text=self.falsePlaceholder, width=5)
        self.isTopTierForFirstTryEntry.pack(side=LEFT)

        self.fm3.pack(fill=BOTH, expand=YES)
