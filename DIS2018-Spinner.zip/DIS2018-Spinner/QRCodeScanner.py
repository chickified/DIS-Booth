import cv2
import tkMessageBox
import zbar
from PIL import Image
from Tkinter import Tk, Label, Entry, Button


class QRCodeScanner:

    def __init__(self):
        self.capture = cv2.VideoCapture(0)
        while True:
            # To quit this program press q.
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

            # Breaks down the video into frames
            self.ret, self.frame = self.capture.read()

            # Displays the current frame
            cv2.imshow('Current', self.frame)

            # Converts image to grayscale.
            self.gray = cv2.cvtColor(self.frame, cv2.COLOR_BGR2GRAY)

            # Uses PIL to convert the grayscale image into a ndary array that ZBar can understand.
            self.image = Image.fromarray(self.gray)
            self.width, self.height = self.image.size
            self.zbar_image = zbar.Image(self.width, self.height, 'Y800', self.image.tostring())

            # Scans the zbar image
            self.scanner = zbar.ImageScanner()
            self.scanner.scan(self.zbar_image)

            # Prints data from image.
            for decoded in self.zbar_image:
                tkMessageBox.showinfo("Say Hello", "Hello World")
                print(decoded.data)
